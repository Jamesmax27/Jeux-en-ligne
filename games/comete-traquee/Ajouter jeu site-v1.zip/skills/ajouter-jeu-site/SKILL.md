---
name: ajouter-jeu-site
description: Publie sur le site de mini-jeux de Jérémy (dépôt GitHub Jamesmax27/Jeux-en-ligne, déployé sur Cloudflare Pages) un jeu HTML créé dans n'importe quelle conversation. À utiliser dès que l'utilisateur dit « pousse ce jeu sur mon site », « ajoute ce jeu au site », « publie ce jeu » ou équivalent. Gère catalogue, genre, tags, idees.json, idees-archive.json et ouvre une pull request via le connecteur GitHub.
---

# Publier un jeu HTML sur le site de mini-jeux

## Contexte fixe
- Dépôt : Jamesmax27/Jeux-en-ligne, branche principale : main.
- Déploiement automatique sur Cloudflare Pages à chaque fusion sur main.
- Le catalogue est la source de vérité de tous les jeux publiés.
- idees.json : idées en attente ou en cours. idees-archive.json : idées faites.
- Une boucle de nuit automatique tourne vers 1 h et 6 h (heure de Paris) et modifie le catalogue et les fichiers d'idées.
- Tous les accès au dépôt passent par le connecteur GitHub (lecture de fichiers, création de branche, push, pull request). Si le connecteur n'est pas disponible, le dire et s'arrêter.

## Entrée
- Le jeu HTML : artefact, fichier joint ou code de la conversation en cours.
- Optionnel : titre, genre, tags souhaités.

## Étapes

1. **Récupérer le jeu** : identifier le code HTML complet et final dans la conversation. S'il y a plusieurs versions, prendre la dernière et la confirmer à l'utilisateur.

2. **Lire les conventions** depuis main, sans rien supposer :
   - le fichier catalogue (le repérer à la racine ou dans le dossier des données),
   - un ou deux jeux existants et leur entrée catalogue : emplacement des fichiers, format du slug, format de la jaquette, champs obligatoires,
   - idees.json et idees-archive.json : format exact des entrées.
   Si un de ces éléments est introuvable ou ambigu, demander à l'utilisateur.

3. **Doublon** : comparer titre et concept avec le catalogue et les titres de idees-archive.json. En cas de jeu très proche, demander avant de continuer.

4. **Genre et tags** :
   - Extraire la liste des genres et tags déjà utilisés dans le catalogue.
   - Choisir en priorité parmi eux ; créer un nouveau tag seulement si aucun ne convient.
   - Proposer titre, slug, genre et tags en une seule question et attendre la validation.

5. **Préparer les fichiers** :
   - le fichier du jeu à l'emplacement conventionnel,
   - la jaquette au format utilisé par les autres jeux,
   - l'entrée catalogue complète,
   - les idées : si une idée correspondante existe dans idees.json, la retirer et l'ajouter à idees-archive.json avec statut "faite" et jeu_id ; sinon, ajouter à idees-archive.json une entrée source "humain", statut "faite", date_ajout du jour, genre, tags, jeu_id.
   Modifier uniquement les entrées concernées et respecter strictement le format existant.

6. **Vérifier avant de pousser** :
   - JSON valides (catalogue, idees.json, idees-archive.json),
   - le jeu est autonome (aucune dépendance locale manquante), sans erreur JavaScript évidente,
   - utilisable sur téléphone : contrôles tactiles, affichage en portrait.
   Signaler tout problème et proposer une correction.

7. **Publier** :
   - Si l'heure de Paris est entre 0 h 45 et 2 h 30 ou entre 5 h 45 et 7 h 30, prévenir qu'une séquence de nuit peut tourner et proposer d'attendre.
   - Créer une branche jeu-manuel/<slug> depuis la dernière version de main.
   - Pousser tous les fichiers en un seul commit : « Ajout manuel : <titre> ».
   - Ouvrir une pull request vers main avec titre, genre, tags et liste des fichiers modifiés.
   - Ne pas fusionner : donner le lien de la PR à l'utilisateur, qui valide.

## Interdits
- Ne pas modifier le système de votes ni la base D1.
- Ne pas modifier les workflows GitHub Actions.
- Ne pas toucher aux autres jeux, aux autres entrées du catalogue ni aux autres idées.
- Ne jamais pousser directement sur main.